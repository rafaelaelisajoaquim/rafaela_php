<?php
    echo "<h1>🚨😱 Área Restrita 😱🚨 </h1>";
    echo "<p>Você não deveria estar aqui, mas conseguiu acessar devido a uma falha de segurança!</p>";
    echo "<p>Isso mostra como ataques SQL Injection podem comprometer sistemas sem proteção adequada.</p>";
    echo "<br><br><br><center><address>Rafaela Elisa Joaquim / Estudante / Técnico em desenvolvimento de sistemas</address></center>";
?>